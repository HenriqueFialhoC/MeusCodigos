#include <stdio.h>

int main(void) {
  int numero;
  printf("Digite um numero: ");
  scanf("%d", &numero);
  if(numero %2 == 0 ){
    printf("%d é divisivel por 2\n", numero);
  }
  if(numero %5 == 0){
    printf("%d é divisivel por 5\n", numero);
  }
  if(numero %10 == 0){
    printf("%d é divisivel por 10\n", numero);
  }
  if (numero %2 != 0 && numero %5 !=0 && numero %10 !=0){
    printf("%d não é divisivel por 2, 5 ou 10", numero);
  }
  return 0;
}