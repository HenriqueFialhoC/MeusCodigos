#include <stdio.h>

int main(void) {
  int numero ;
  printf("Digite um numero inteiro: ");
  scanf("%i", &numero);
  if(numero % 2 == 0 ){
    printf("%d é um número par/n", numero);
    } else{
    printf("%d é um número impar/n, numero");
    }
  
  return 0;
}