#include <stdio.h>

int main(void) {
  int idade;
  printf("Digite sua idade: ");
  scanf("%d", &idade);
  if (idade < 16){
    printf("esta pessoa não é eleitora");
 } else if (idade >= 16 && idade <= 17) {
        printf("Esta pessoa é um eleitor facultativo menor de idade.\n");
    } else if (idade >= 18 && idade <= 64) {
        printf("Esta pessoa é um eleitor obrigatório.\n");
    } else {
        printf("Esta pessoa é um eleitor facultativo maior de idade.\n");
    }

    return 0;
}