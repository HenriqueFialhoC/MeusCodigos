#include <stdio.h>

int main() {
    int corX, corY, corZ;

    printf("Digite as cores em hexadecimal (RRGGBB): ");
    scanf("%2x%2x%2x", &corX, &corY, &corZ);

    if (corX < 0 || corX > 255 || corY < 0 || corY > 255 || corZ < 0 || corZ > 255) {
        printf("Valores inválidos! Certifique-se de que as cores estejam no formato hexadecimal (00 a FF).\n");
        return 1; 
    }

    printf("Cor vermelha: %d\n", corX);
    printf("Cor verde: %d\n", corY);
    printf("Cor azul: %d\n", corZ);

    return 0;
}
