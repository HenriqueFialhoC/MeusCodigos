#include <stdio.h>
#include <math.h>

int main() {
    double area_base, altura, volume, area_superficial;

    
    printf("Digite a área da base da pirâmide (em metros quadrados): ");
    scanf("%lf", &area_base);

    printf("Digite a altura da pirâmide (em metros): ");
    scanf("%lf", &altura);

   
    volume = (1.0 / 3.0) * area_base * altura;

   
    double lado_base = sqrt(area_base);
    area_superficial = area_base + 4.0 * (lado_base * sqrt((lado_base * lado_base) / 4.0 + altura * altura));

    
    printf("O volume da pirâmide é: %.2lf metros cúbicos\n", volume);
    printf("A área superficial da pirâmide é: %.2lf metros quadrados\n", area_superficial);

    return 0;
}
