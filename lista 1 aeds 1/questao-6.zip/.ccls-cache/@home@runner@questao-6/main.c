#include <stdio.h>
#include <stdlib.h>

int main() {
    char hexColor[7];
    int vermelho, verde, azul;

    printf("Digite o código hexadecimal da cor (RRGGBB): ");
    scanf("%6s", hexColor); 

   
   vermelho = strtol(hexColor, NULL, 16);  
    verde = strtol(hexColor + 2, NULL, 16); 
    azul = strtol(hexColor + 4, NULL, 16);  

    
    if (vermelho >= 0 && vermelho <= 255 && verde >= 0 && verde <= 255 && azul >= 0 && azul <= 255) {
        printf("Cor RGB: (%d, %d, %d)\n", vermelho, verde, azul);
    } else {
        printf("Valores inválidos. Certifique-se de usar uma representação hexadecimal correta (0x00 a 0xFF) para cada cor.\n");
    }

    return 0;
}
