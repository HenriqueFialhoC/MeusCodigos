#include <stdio.h>
#include <math.h>

int main(void) {
  double cateto1, cateto2, hipotenusa, angulo1, angulo2, area, perimetro;
  printf("digite o valor correspondente ao cateto1: ");
  scanf("%lf", &cateto1);
      printf("digite o valor correspondente ao cateto2: ");
  scanf("%lf", &cateto2);
    //calcular hipotenusa
hipotenusa = sqrt(cateto1 * cateto1 + cateto2 * cateto2);
    // Calcular a área
    area = 0.5 * cateto1 * cateto2;

    // Calcular o perímetro
    perimetro = cateto1 + cateto2 + hipotenusa;

    // Calcular os ângulos adjacentes
    angulo1 = atan(cateto1 / cateto2) * (180.0 / M_PI);
    angulo2 = atan(cateto2 / cateto1) * (180.0 / M_PI);

    // Imprimir os resultados
    printf("A hipotenusa do triângulo é: %.2lf\n", hipotenusa);
    printf("A área do triângulo é: %.2lf\n", area);
    printf("O perímetro do triângulo é: %.2lf\n", perimetro);
    printf("Os ângulos adjacentes aos catetos são: %.2lf graus e %.2lf graus\n", angulo1, angulo2);

  return 0;
}