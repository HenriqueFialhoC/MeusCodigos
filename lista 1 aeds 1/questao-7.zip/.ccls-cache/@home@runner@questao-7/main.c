#include <stdio.h>
#include <math.h>

typedef struct {
    double x;
    double y;
} Vector;

double dotProduct(Vector v1, Vector v2) {
    return (v1.x * v2.x + v1.y * v2.y);
}

double magnitude(Vector v) {
    return sqrt(v.x * v.x + v.y * v.y);
}

double angleBetweenVectors(Vector v1, Vector v2) {
    double dot = dotProduct(v1, v2);
    double mag1 = magnitude(v1);
    double mag2 = magnitude(v2);
    
    return acos(dot / (mag1 * mag2)) * 180.0 / M_PI; // Ângulo em graus
}

Vector crossProduct(Vector v1, Vector v2) {
    Vector result;
    result.x = v1.x * v2.y - v1.y * v2.x;
    result.y = v1.y * v2.x - v1.x * v2.y;
    return result;
}

int main() {
    Vector vector1, vector2;
    
    printf("Digite as coordenadas do primeiro vetor (x y): ");
    scanf("%lf %lf", &vector1.x, &vector1.y);
    
    printf("Digite as coordenadas do segundo vetor (x y): ");
    scanf("%lf %lf", &vector2.x, &vector2.y);
    
    // Calcula o produto escalar entre os vetores
    double scalarProduct = dotProduct(vector1, vector2);
    
    // Calcula o ângulo entre os vetores
    double angle = angleBetweenVectors(vector1, vector2);
    
    // Calcula o produto vetorial entre os vetores
    Vector cross = crossProduct(vector1, vector2);
    
    printf("Produto escalar: %.2lf\n", scalarProduct);
    printf("Ângulo entre os vetores: %.2lf graus\n", angle);
    printf("Produto vetorial: (%.2lf, %.2lf)\n", cross.x, cross.y);
    
    return 0;
}
