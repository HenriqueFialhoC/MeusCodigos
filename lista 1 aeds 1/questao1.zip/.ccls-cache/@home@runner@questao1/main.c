#include <stdio.h>

int main() {
   
    char nome[] = "Henrique Cardoso";
    int matricula = 812290;

    printf("Este é o primeiro programa que fazemos em linguagem C.\n");
    printf("Aluno: %s, matrícula %d\n", nome, matricula);

    return 0;
}
