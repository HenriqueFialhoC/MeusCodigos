#include <stdio.h>
#include <string.h>

int main() {
    char nome[100]; 

    printf("Digite o seu nome completo: ");
    fgets(nome, sizeof(nome), stdin);

    if (nome[strlen(nome) - 1] == '\n') {
        nome[strlen(nome) - 1] = '\0';
    }

    int numCaracteres = strlen(nome);

    printf("O seu nome tem %d caracteres.\n", numCaracteres);

    return 0;
}
